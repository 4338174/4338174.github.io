module.exports = (server) => {
	require('./produkt')(server);
};