module.exports = (server) => {
	require('./produkt')(server);
	require('./login')(server);
};
